"""
tcp 多线程并发模型
"""
import sys
from threading import Thread
from socket import *

HOST = "0.0.0.0"
PORT = 8888
ADDR = (HOST, PORT)


def handle(c):
    while True:
        data = c.recv(1024).decode()
        if not data:
            break
        print("客户端：", data)
        c.send(b"OK")
    c.close()


def main():
    s = socket(AF_INET, SOCK_DGRAM)
    s.bind(ADDR)
    s.listen(3)

    while True:
        try:
            c, addr = s.accept()
            print("connect from", addr)
        except KeyboardInterrupt as e:
            s.close()
            sys.exit("服务端退出！")  # 进程退出
        p = Thread(target=handle, args=(c,))
        p.start()

if __name__ == '__main__':
    main()