"""
ftp客户端
c/s模型   发送请求，获取结果
"""
import sys
from socket import *
import time

ADDR = ("127.0.0.1", 8888)


# 将具体发送请求的方法封装在类中
class FTPClient:
    def __init__(self, sock=None):
        self.sock = sock

    # 请求文件列表
    def do_list(self):
        self.sock.send("LIST".encode())
        result = self.sock.recv(128).decode()
        if result == "OK":
            while True:
                file = self.sock.recv(1024).decode()
                if file == "##":
                    break
                print(file)
        else:
            print("文件库为空")

    #  下载文件
    def do_get(self,filename):
        data = "GET " + filename
        self.sock.send(data.encode())
        result = self.sock.recv(128).decode()
        if result == "OK" :
            fw = open(filename, "wb")
            while True:
                data = self.sock.recv(1024)
                if data == b"##":
                    break
                fw.write(data)
            fw.close()

        else:
            print("文件不存在")

    # 上传文件
    def do_put(self, filename):
        try:
            f = open(filename,"rb")
        except:
            print("上传文件不存在")
            return
        filename = filename.split("/")[-1]
        data = "PUT " + filename
        self.sock.send(data.encode())
        result = self.sock.recv(128).decode()
        if result == "OK":
            while True:
                data = f.read(1024)
                if not data:
                    time.sleep(0.1)
                    self.sock.send(b"##")
                    break
                self.sock.send(data)
            f.close()
        else:
            print("该文件存在")

    # 退出
    def do_exit(self):
        self.sock.send("EXIT")
        self.sock.close()
        sys.exit("退出")


def main():
    sock = socket()
    sock.connect(ADDR)

    ftp = FTPClient(sock)

    while True:
        print("=============命令选项=============")
        print("***           list            ***")
        print("***         get file          ***")
        print("***         put file          ***")
        print("***           exit            ***")
        print("=================================")

        cmd = input("请输入命令：")
        if cmd == "list":
            ftp.do_list()
        elif cmd[:3] == "get":
            filename = cmd.split(" ")[-1]
            ftp.do_get(filename)
        elif cmd[:3] == "put":
            filename = cmd.split(" ")[-1]
            ftp.do_put(filename)
        elif cmd[:3] == "exit":
            ftp.do_exit()
        else:
            print("请输入正确命令")

if __name__ == '__main__':
    main()