"""
tcp多进程并发模型
"""
import sys
from multiprocessing import Process
from socket import *
from signal import *

HOST = "0.0.0.0"
PORT = 8888
ADDR = (HOST, PORT)


def handle(c):
    while True:
        data = c.recv(1024).decode()
        if not data:
            break
        print("客户端：", data)
        c.send(b"OK")
    c.close()


def main():
    s = socket(AF_INET, SOCK_DGRAM)
    s.bind(ADDR)
    s.listen(3)

    signal(SIGCHLD, SIG_IGN)  # 处理僵尸进程

    while True:
        try:
            c, addr = s.accept()
            print("connect from", addr)
        except KeyboardInterrupt as e:
            s.close()
            sys.exit("客户端退出！")
        p = Process(target=handle, args=(c,))
        p.daemon = True  # 如果父进程退出，所有客户端立即终止则添加
        p.start()


if __name__ == '__main__':
    main()